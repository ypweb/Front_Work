/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CommentTableComponent } from './comment-table.component';

describe('Component: CommentTable', () => {

});
