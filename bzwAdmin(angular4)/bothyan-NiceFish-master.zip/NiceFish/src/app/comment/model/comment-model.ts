export class Comment{
    id: number;
    postId: number;
    content: string;
    date: Date;
    username: string;
}