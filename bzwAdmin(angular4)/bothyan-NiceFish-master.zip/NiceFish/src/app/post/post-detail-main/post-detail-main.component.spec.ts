/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { PostDetailMainComponent } from './post-detail-main.component';

describe('Component: PostDetailMain', () => {
	
});
