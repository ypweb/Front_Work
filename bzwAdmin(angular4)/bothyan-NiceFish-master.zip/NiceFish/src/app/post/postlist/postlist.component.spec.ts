/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { PostlistComponent } from './postlist.component';

describe('Component: Postlist', () => {
	
});
