export class Post {
  id: number
  title: string
  text: string
  author: string
  postTime: Date
  readTimes: number
  commentTimes: number
}