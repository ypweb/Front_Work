import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-social-channel',
  templateUrl: './social-channel.component.html',
  styleUrls: ['./social-channel.component.scss']
})
export class SocialChannelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  	
  }
}
