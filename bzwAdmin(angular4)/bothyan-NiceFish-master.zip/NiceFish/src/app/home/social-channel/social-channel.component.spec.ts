/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SocialChannelComponent } from './social-channel.component';

describe('Component: SocialChannel', () => {

});
