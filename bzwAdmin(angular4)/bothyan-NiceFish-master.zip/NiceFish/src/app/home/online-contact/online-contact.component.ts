import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-online-contact',
  templateUrl: './online-contact.component.html',
  styleUrls: ['./online-contact.component.scss']
})
export class OnlineContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
