/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { UserRegisterComponent } from './user-register.component';

describe('Component: UserRegister', () => {
	
});
