/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ForgetPwdComponent } from './forget-pwd.component';

describe('Component: ForgetPwd', () => {
	
});
