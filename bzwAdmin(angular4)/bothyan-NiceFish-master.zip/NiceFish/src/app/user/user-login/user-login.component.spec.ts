/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { UserLoginComponent } from './user-login.component';

describe('Component: UserLogin', () => {
	
});
