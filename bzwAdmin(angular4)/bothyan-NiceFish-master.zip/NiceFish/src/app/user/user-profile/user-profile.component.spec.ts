/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { UserProfileComponent } from './user-profile.component';

describe('Component: UserProfile', () => {
	
});
